function h1(text) {
    document.write('<h1>'+text+'</h1>');
}