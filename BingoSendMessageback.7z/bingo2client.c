// wuclient.c
// Weather update client
// Connects SUB socket to tcp://localhost:5556
// Collects weather updates and finds avg temp in zipcode 
//
#include <zhelpers.h>

int validate(int card[], int number){
	for(int i = 0; i<25;i++){
		if(number == card[i]){			
			return 1;
		}
	}
	return 0;
}

int put_a_seed_on(int card[], int number, int counter){
	for(int i = 0; i<25;i++){		
		if(number == card[i]){			
			return counter += 1;						
		}
	}
	return counter;
}

int main (int argc, char *argv []) {
  void *context = zmq_ctx_new ();
	
	int card[25];
//  Initialize random number generator
  srandom ((unsigned) time (NULL));	
	for(int i =0; i <25; i++){	
		int number = randof(101);
		while (validate(card,number)){			
			number = randof(101);
		}
		card[i]=number;
	}
	
	for(int i =0; i <25; i++){
		printf("Los valores del bingo son: %d\n",card[i]);
	}
	
  //  Socket to talk to server
  printf ("Collecting updates from weather server...\n"); 
  void *subscriber = zmq_socket (context, ZMQ_SUB);
  int rc = zmq_connect (subscriber, "tcp://localhost:5556"); 
  void* requester = zmq_socket(context, ZMQ_REQ);
  zmq_connect(requester, "tcp://localhost:5555");
  //assert (rc == 0);

  //  Subscribe to zipcode, default is NYC, 10001
  //char *filter = (argc > 1)? argv [1]: "10001 ";
  char *filter = "";
  rc = zmq_setsockopt (subscriber, ZMQ_SUBSCRIBE, filter, strlen (filter)); 
  //assert (rc == 0);

  //  Process 100 updates
  int update_nbr;
  long number = 0;
  int flag = 1;
  int counter = 0;
  while(flag) {	  
    char *string = s_recv (subscriber,0);    
    sscanf (string, "%d",
       &number);  	   
    free (string);	
	if(number>=0){
		printf("Number: %d, Seed used: %d\n", number, counter);
		counter = put_a_seed_on(card,number,counter);	
		if(counter == 25){			
			flag = 0;
			char* bingo = "Bingo";
			s_send(requester, bingo);
			printf("After Send %s\n",bingo);
		}
	}
	else{
		flag = 0;
		printf("Game Over/n");
	}
  }  

  zmq_close (subscriber);
  zmq_close (requester);
  zmq_ctx_destroy (context); 
  
  printf("Bingo");
  system("COLOR 70");
  
  getchar();
  return 0;
}