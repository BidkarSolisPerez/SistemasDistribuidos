#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h>

#include <nxjson.h>

struct Professor{
	int id, phone;
	char name[50];
	char degree[50];
	char email[50];
};

int main() {
  FILE *f = fopen("data.json", "rb");
  fseek(f, 0, SEEK_END);
  long fsize = ftell(f);
  fseek(f, 0, SEEK_SET);  /* same as rewind(f); */

  char *input = malloc(fsize + 1);
  fread(input, 1, fsize, f);
  fclose(f);

  input[fsize] = 0;
  
  char stringread [50] = "";
  int intread = 0;  
  double doubleread = 0.0;
  char auxsql [150] = "";
  int counter = 0;
  sqlite3 *db;
	char *err_msg = 0;

	int rc = sqlite3_open("test.db", &db);

	if (rc != SQLITE_OK) {

		fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		return 1;
	}

	char *sql = "DROP TABLE IF EXISTS Professor;" 
				"CREATE TABLE Professor(Id INT, Name TEXT, Degree TEXT, Email TEXT, Phone INT);" ;
	rc = sqlite3_exec(db, sql, 0, 0, &err_msg);

		if (rc != SQLITE_OK ) {

			fprintf(stderr, "SQL error: %s\n", err_msg);
			sqlite3_free(err_msg);        
			sqlite3_close(db);
			return 1;
		}
		else printf("Tabla Creada\n");
		
		
		//free(sql);
		
  const nx_json* json=nx_json_parse_utf8(input);

  const nx_json* professors = nx_json_get(json, "professors");
   nx_json* prof=professors->child;   
   for (prof=professors->child; prof; prof=prof->next) {
     nx_json* field=prof->child;
	 counter = 0;
	 struct Professor p1;
     for (field=prof->child; field; field=field->next) {		 
		 printf("Counter Value is: %d\n", counter);
       if (field->type==NX_JSON_STRING){
          //printf("%s => %s\n",field->key, field->text_value);		  
		  strcpy(stringread, field->text_value);
		  printf("Reading %s\n", stringread);
		  if(counter == 1){
			  strcpy(p1.name, stringread);
		  }
		  else if (counter == 2){
			  strcpy(p1.degree, stringread);
		  }
		  else{
			  strcpy(p1.email, stringread);
		  }
	   }
       else if (field->type==NX_JSON_INTEGER){
          //printf("%s => %d\n",field->key, field->int_value);		  
		  intread = field->int_value;
		  printf("Reading Int %d\n", intread);
		  if(counter == 0){
			  p1.id = intread;
		  }
		  else{
			  p1.phone = intread;
		  }
	   }
       else if (field->type==NX_JSON_DOUBLE){
          //printf("%s => %f\n",field->key, field->dbl_value);		  
		  doubleread = field->dbl_value;
		  printf("Reading Float %f\n", doubleread);
	   }
	   counter++;	   
     }
	 printf("The Obj is: name: %s email: %s degree: %s id: %d phone: %d", p1.name, p1.email, p1.degree, p1.id, p1.phone);
	 sprintf (auxsql,"INSERT INTO Professor (Id, Name, Degree, Email, Phone) VALUES (%d,'%s','%s','%s',%d);",p1.id, p1.name, p1.email, p1.degree, p1.phone);
	 printf("Valor de SQL %s", auxsql);

    rc = sqlite3_exec(db, auxsql, 0, 0, &err_msg);

    if (rc != SQLITE_OK ) {

        fprintf(stderr, "SQL error: %s\n", err_msg);
        sqlite3_free(err_msg);        
        sqlite3_close(db);
		getchar();
        return 1;
    }
	else printf("Agregado\n");
     printf("\n");	 
   }
   sqlite3_close(db);
   getchar();
}