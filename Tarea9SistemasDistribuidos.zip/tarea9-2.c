#include <sqlite3.h>
#include <stdio.h>

int callback(void *, int, char **, char **);

int main(void) {

    sqlite3 *db;
	sqlite3_stmt *stmt;
    char *err_msg = 0;

    int rc = sqlite3_open("test.db", &db);

    if (rc != SQLITE_OK) {
        fprintf(stderr, "Cannot open database: %s\n", 
                sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
		
	rc = sqlite3_prepare_v2(db, "select count(*) from Professor", -1, &stmt, NULL);
	if (rc != SQLITE_OK) {
	  // error handling -> statement not prepared
	}
	rc = sqlite3_step(stmt);
	if (rc != SQLITE_ROW) {
	  // error handling -> no rows returned, or an error occurred
	}
	int rowcount = sqlite3_column_int(stmt, 0);
	
	printf("Row: %d", rowcount);
	
	sqlite3_prepare_v2(db, "select * from Professor", -1, &stmt, NULL);
	FILE *file_pointer; 
	
	// open the file "name_of_file.txt" for writing
	file_pointer = fopen("test.json", "w"); 
 
	// Write to the file
	fprintf(file_pointer, "{\"title\":\"Listado de Profesores\",\"professors\":[");
		
	int counter = 1;
	while (sqlite3_step(stmt) != SQLITE_DONE) {
		int i;
		int num_cols = sqlite3_column_count(stmt);
		
		for (i = 0; i < num_cols; i++)
		{
			if(i == 0) {
			fprintf(file_pointer,"{\"id\":");
			fprintf(file_pointer,sqlite3_column_text(stmt, i));
			fprintf(file_pointer,",");
			}
			else if(i == 1){
				fprintf(file_pointer,"\"name\":");
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,sqlite3_column_text(stmt, i));
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,",");
			}
			else if(i == 2){
				fprintf(file_pointer,"\"email\":");
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,sqlite3_column_text(stmt, i));
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,",");
			}
			else if(i == 3){
				fprintf(file_pointer,"\"degree\":");
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,sqlite3_column_text(stmt, i));
				fprintf(file_pointer,"\"");
				fprintf(file_pointer,",");
			}
			else if(i == 4){
				fprintf(file_pointer,"\"phone\":");
				fprintf(file_pointer,sqlite3_column_text(stmt, i));		    			
				if(counter != rowcount) fprintf(file_pointer,"},");
				else fprintf(file_pointer,"}");
			}
			/*switch (sqlite3_column_type(stmt, i))
			{
			case (SQLITE3_TEXT):
				printf("%s, ", sqlite3_column_text(stmt, i));
				break;
			case (SQLITE_INTEGER):
				printf("%d, ", sqlite3_column_int(stmt, i));
				break;
			case (SQLITE_FLOAT):
				printf("%g, ", sqlite3_column_double(stmt, i));
				break;
			default:
				break;
			}*/
		}
		counter++;
		//printf("\n");

	}

	sqlite3_finalize(stmt);
	fprintf(file_pointer, "]}");
	fclose(file_pointer);
	sqlite3_close(db);	  
	getchar();
    return 0;
}