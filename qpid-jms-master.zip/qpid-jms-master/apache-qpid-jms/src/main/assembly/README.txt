Apache Qpid JMS


For a basic overview of the client JNDI configuration and
URI options, see the docs directory.

For examples of using the client, see the examples directory.

The client artifacts and required dependencies can be found
in the lib directory.
